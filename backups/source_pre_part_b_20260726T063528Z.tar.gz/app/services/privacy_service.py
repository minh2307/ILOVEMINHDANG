from __future__ import annotations

import re


PHONE_TOKEN = "[ĐÃ ẨN SỐ ĐIỆN THOẠI]"
EMAIL_TOKEN = "[ĐÃ ẨN EMAIL]"
PATIENT_ID_TOKEN = "[ĐÃ ẨN MÃ BỆNH NHÂN]"
MEDICAL_RECORD_TOKEN = "[ĐÃ ẨN MÃ HỒ SƠ]"
IDENTITY_TOKEN = "[ĐÃ ẨN THÔNG TIN ĐỊNH DANH]"


class PrivacyService:
    """Deterministically masks obvious identifiers without changing clinical units."""

    _email = re.compile(r"(?<![\w.+-])[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}(?!\w)")
    _phone = re.compile(
        r"(?<!\w)(?:\+?84[ .-]?|0)(?:\d[ .-]?){8,10}(?!\w)", re.IGNORECASE
    )
    _medical_record = re.compile(
        r"\b(?:mã\s*(?:hồ\s*sơ|hs)|mrn|medical\s*record(?:\s*id)?)"
        r"\s*[:#-]?\s*[A-Z0-9][A-Z0-9._/-]{2,}\b",
        re.IGNORECASE,
    )
    _patient_id = re.compile(
        r"\b(?:mã\s*(?:bệnh\s*nhân|bn)|patient\s*id)"
        r"\s*[:#-]?\s*[A-Z0-9][A-Z0-9._/-]{2,}\b",
        re.IGNORECASE,
    )
    _national_id = re.compile(
        r"\b(?:(?:cccd|cmnd|căn\s*cước|national\s*id)\s*[:#-]?\s*)?\d{9,12}\b",
        re.IGNORECASE,
    )
    _url = re.compile(r"https?://[^\s<>()]+", re.IGNORECASE)
    _handle = re.compile(r"(?<![\w@])@[A-Za-z0-9._-]{2,}")
    _explicit_name = re.compile(
        r"\b(?:họ\s*(?:và\s*)?tên|tên\s*bệnh\s*nhân|bệnh\s*nhân|patient\s*name)"
        r"\s*:\s*[A-ZÀ-Ỹ][A-Za-zÀ-ỹ]*(?:\s+[A-ZÀ-Ỹ][A-Za-zÀ-ỹ]*){1,5}",
        re.IGNORECASE,
    )
    _explicit_identity = re.compile(
        r"\b(?:địa\s*chỉ|address|tài\s*khoản|account)\s*:\s*[^;\n]{3,}",
        re.IGNORECASE,
    )

    def mask(self, text: str | None, *, full_names: tuple[str, ...] = ()) -> str:
        value = str(text or "")
        for name in sorted({item.strip() for item in full_names if item.strip()}, key=len, reverse=True):
            value = re.sub(re.escape(name), IDENTITY_TOKEN, value, flags=re.IGNORECASE)
        value = self._email.sub(EMAIL_TOKEN, value)
        value = self._medical_record.sub(MEDICAL_RECORD_TOKEN, value)
        value = self._patient_id.sub(PATIENT_ID_TOKEN, value)
        value = self._phone.sub(PHONE_TOKEN, value)
        value = self._national_id.sub(IDENTITY_TOKEN, value)
        value = self._url.sub(IDENTITY_TOKEN, value)
        value = self._handle.sub(IDENTITY_TOKEN, value)
        value = self._explicit_name.sub(IDENTITY_TOKEN, value)
        value = self._explicit_identity.sub(IDENTITY_TOKEN, value)
        return value

    def contains_obvious_identifier(self, text: str | None) -> bool:
        value = str(text or "")
        return any(
            pattern.search(value)
            for pattern in (
                self._email,
                self._medical_record,
                self._patient_id,
                self._phone,
                self._national_id,
                self._url,
                self._handle,
                self._explicit_name,
                self._explicit_identity,
            )
        )
