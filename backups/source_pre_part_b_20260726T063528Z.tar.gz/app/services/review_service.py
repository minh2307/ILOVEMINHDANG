from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import subprocess
from typing import Callable

from app.config.settings import Settings
from app.models.workflow import WorkflowStatus
from app.repositories.job_repository import JobRepository
from app.services.clinical_factors_service import ClinicalFactorsService


@dataclass(frozen=True, slots=True)
class ReviewDecision:
    action: str
    exit_code: int = 0


class ReviewService:
    """Presents the Phase 3 checkpoint without performing any publication."""

    def __init__(
        self,
        settings: Settings,
        repository: JobRepository,
        clinical_factors: ClinicalFactorsService | None = None,
    ) -> None:
        self.settings = settings
        self.repository = repository
        self.clinical_factors = clinical_factors or ClinicalFactorsService(
            max_response_chars=settings.clinical_factors_max_chars,
            max_comment_chars=settings.clinical_factors_comment_max_chars,
            max_comments=settings.clinical_factors_max_comments,
            max_total_comment_chars=settings.gemini_comment_total_max_chars,
            max_prompt_chars=settings.gemini_prompt_max_chars,
        )

    def review(
        self,
        job_id: str,
        *,
        choice_provider: Callable[[str], str] = input,
        edited_text_provider: Callable[[], str] | None = None,
    ) -> ReviewDecision:
        job = self.repository.get_job(job_id)
        if job is None:
            raise LookupError(f"Job not found: {job_id}")
        if job.status is not WorkflowStatus.WAITING_FOR_REVIEW:
            raise ValueError(
                f"--review-job requires WAITING_FOR_REVIEW; got {job.status.value}"
            )
        self.display(job_id)
        choice = choice_provider("Select [1-7]: ").strip()
        if choice == "1":
            self.repository.transition(
                job_id,
                WorkflowStatus.APPROVED,
                details={"review_decision": "approved_for_later_phase4"},
            )
            return ReviewDecision("approved")
        if choice == "2":
            self.repository.transition(
                job_id,
                WorkflowStatus.REJECTED,
                details={"review_decision": "rejected"},
            )
            return ReviewDecision("rejected")
        if choice == "3":
            provider = edited_text_provider or self._read_multiline_edit
            self._save_edited_factors(job_id, provider())
            self.repository.transition(
                job_id,
                WorkflowStatus.RETRY_PENDING,
                details={"review_decision": "clinical_factors_edited", "retry_step": "cdha"},
            )
            return ReviewDecision("retry_cdha")
        if choice == "4":
            self.repository.transition(
                job_id,
                WorkflowStatus.RETRY_PENDING,
                details={"review_decision": "retry_gemini", "retry_step": "gemini"},
            )
            return ReviewDecision("retry_gemini")
        if choice == "5":
            self.repository.transition(
                job_id,
                WorkflowStatus.RETRY_PENDING,
                details={"review_decision": "retry_cdha", "retry_step": "cdha"},
            )
            return ReviewDecision("retry_cdha")
        if choice == "6":
            folder = (self.settings.job_data_dir / job_id / "screenshots").resolve()
            folder.mkdir(parents=True, exist_ok=True)
            try:
                subprocess.Popen(
                    ["xdg-open", str(folder)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
                print(f"Opened screenshot folder: {folder}")
            except OSError as exc:
                print(f"Could not open the folder automatically ({exc}). Folder: {folder}")
            return ReviewDecision("show_screenshot_folder")
        if choice == "7":
            print("Review left pending. Resume later with --review-job.")
            return ReviewDecision("resume_later")
        raise ValueError("Review selection must be a number from 1 to 7")

    def display(self, job_id: str) -> None:
        job = self.repository.get_job(job_id)
        if job is None:
            raise LookupError(f"Job not found: {job_id}")
        data = job.data
        result = data.get("cdha_result") or {}
        print("=" * 50)
        print("CDHA ANALYSIS READY FOR REVIEW")
        print("=" * 50)
        print(f"Job ID: {job.job_id}")
        print(f"Source Reel: {job.source_url}")
        print(f"Video path: {data.get('video_path') or ''}")
        print(f"Clinical Factors path: {data.get('clinical_factors_path') or ''}")
        print(f"CDHA result path: {data.get('cdha_result_json_path') or ''}")
        print(f"Screenshot folder: {self.settings.job_data_dir / job.job_id / 'screenshots'}")
        print(f"Triage: {result.get('triage') or ''}")
        print(f"Confidence: {result.get('confidence') or ''}")
        print(f"Key Findings: {result.get('key_findings') or []}")
        print(f"Impression: {result.get('impression') or ''}")
        print(f"Warnings: {result.get('warnings') or data.get('cdha_warnings') or []}")
        print("\n[1] Approve for later Facebook publishing")
        print("[2] Reject")
        print("[3] Edit Clinical Factors")
        print("[4] Retry Gemini")
        print("[5] Retry CDHA")
        print("[6] Open screenshot folder")
        print("[7] Stop and resume later")

    def _save_edited_factors(self, job_id: str, edited: str) -> None:
        result = self.clinical_factors.validate(edited, job_id=job_id)
        if not result.success:
            raise ValueError(result.error or "Edited Clinical Factors failed validation")
        job_dir = (self.settings.job_data_dir / job_id).resolve()
        normalized_path = job_dir / "clinical-factors-normalized.txt"
        masked_path = job_dir / "clinical-factors-masked.txt"
        self._write_text_atomic(normalized_path, result.normalized_text)
        self._write_text_atomic(masked_path, result.masked_text)
        self.repository.update_data(
            job_id,
            {
                "clinical_factors": result.masked_text,
                "clinical_factors_normalized_path": str(normalized_path),
                "clinical_factors_path": str(masked_path),
                "clinical_factors_missing_fields": result.missing_fields,
                "clinical_factors_warnings": result.validation_warnings,
            },
        )

    @staticmethod
    def _read_multiline_edit() -> str:
        print("Paste the complete edited Clinical Factors. Enter a single '.' line to finish:")
        lines: list[str] = []
        while True:
            line = input()
            if line == ".":
                return "\n".join(lines)
            lines.append(line)

    @staticmethod
    def _write_text_atomic(path: Path, text: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(text, encoding="utf-8")
        temporary.replace(path)
