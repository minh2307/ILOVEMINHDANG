from __future__ import annotations

import json
import logging
import re
import sys
from datetime import UTC, datetime
from logging.handlers import RotatingFileHandler
from typing import Any

from app.config.settings import Settings


_STANDARD_FIELDS = set(logging.makeLogRecord({}).__dict__)
_SENSITIVE_PATTERNS = (
    re.compile(r"(?i)(authorization\s*[:=]\s*bearer\s+)[^\s,;]+"),
    re.compile(r"(?i)\b(password|passwd|token|access_token|api_key|cookie)\s*[:=]\s*[^\s,;]+"),
)


def mask_sensitive(value: str) -> str:
    masked = value
    for pattern in _SENSITIVE_PATTERNS:
        if pattern.groups == 1:
            masked = pattern.sub(r"\1[REDACTED]", masked)
        else:
            masked = pattern.sub(lambda match: f"{match.group(1)}=[REDACTED]", masked)
    return masked


class StructuredJsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": mask_sensitive(record.getMessage()),
        }
        for key, value in record.__dict__.items():
            if key not in _STANDARD_FIELDS and not key.startswith("_"):
                try:
                    json.dumps(value)
                    payload[key] = mask_sensitive(value) if isinstance(value, str) else value
                except (TypeError, ValueError):
                    payload[key] = mask_sensitive(str(value))
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def configure_logging(settings: Settings) -> logging.Logger:
    settings.log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("cdha_pipeline")
    logger.setLevel(getattr(logging, settings.log_level, logging.INFO))
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()

    formatter = StructuredJsonFormatter()
    file_handler = RotatingFileHandler(
        settings.log_dir / "workflow.jsonl",
        maxBytes=settings.log_max_bytes,
        backupCount=settings.log_backup_count,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    stream_handler = logging.StreamHandler(sys.stderr)
    stream_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    return logger


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"cdha_pipeline.{name}")
