from __future__ import annotations

import asyncio
import logging
import re
import subprocess
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

from app.browser.chrome_manager import ChromeManager
from app.browser.selector_resolver import SelectorResolutionError, SelectorResolver
from app.config.settings import Settings
from app.models.results import (
    FacebookCommentResult,
    FacebookPermalinkResult,
    FacebookPostPreparationResult,
    FacebookPublishResult,
)
from app.models.workflow import WorkflowStatus
from app.repositories.job_repository import JobRepository
from app.services.post_content_service import PostContentService


class FacebookManualActionRequired(RuntimeError):
    pass


class FacebookPublicationUncertain(RuntimeError):
    pass


class FacebookWebClient:
    """Single async Playwright publisher, informed by the legacy bilingual selectors."""

    def __init__(
        self,
        settings: Settings,
        repository: JobRepository,
        chrome: ChromeManager,
        *,
        resolver: SelectorResolver | None = None,
        content: PostContentService | None = None,
        confirmation_provider: Callable[[str], str] = input,
        edit_provider: Callable[[], str] | None = None,
        screenshot_selection_provider: Callable[[str], str] = input,
        force_publish: bool = False,
        logger: logging.Logger | None = None,
    ) -> None:
        self.settings = settings
        self.repository = repository
        self.chrome = chrome
        self.resolver = resolver or SelectorResolver(settings.selectors_path)
        self.content = content or PostContentService(settings)
        self.confirmation_provider = confirmation_provider
        self.edit_provider = edit_provider or self._read_multiline_edit
        self.screenshot_selection_provider = screenshot_selection_provider
        self.force_publish = force_publish
        self.logger = logger or logging.getLogger("cdha_pipeline.facebook")
        self._pages: dict[str, Any] = {}

    async def prepare_post(
        self,
        *,
        target_url: str,
        post_text: str,
        image_paths: list[Path],
        job_id: str,
    ) -> FacebookPostPreparationResult:
        target = self.content.normalize_target_url(target_url)
        job = self._require_job(job_id)
        cdha_view_url = str(job.data.get("cdha_view_url") or "")
        self.content.validate_post_text(
            post_text, source_url=job.source_url, cdha_view_url=cdha_view_url
        )
        images = [self.content.validate_image(path) for path in image_paths]
        if not images:
            raise ValueError("At least one validated screenshot is required")
        if len(images) > self.settings.facebook_max_image_count:
            raise ValueError("Facebook image count exceeds configured limit")
        fingerprint = self.content.content_fingerprint(target, post_text, images)
        self._guard_duplicate(job_id, target, fingerprint)
        job = self._require_job(job_id)
        if job.status is WorkflowStatus.FACEBOOK_PUBLISH_FAILED:
            job = self.repository.transition(
                job_id, WorkflowStatus.RETRY_PENDING,
                details={"retry_step": "facebook_prepare"},
            )
        if job.status not in {WorkflowStatus.APPROVED, WorkflowStatus.RETRY_PENDING}:
            raise ValueError(f"Facebook preparation requires APPROVED; got {job.status.value}")
        image_hashes = [self.content.image_sha256(path) for path in images]
        self.repository.transition(
            job_id,
            WorkflowStatus.FACEBOOK_PREPARING,
            details={"target_url": target, "image_count": len(images)},
            data_patch={
                "retain_assets": True,
                "facebook_target_url": target,
                "facebook_target_type": self.settings.facebook_target_type,
                "facebook_post_text": post_text,
                "facebook_image_paths": [str(path) for path in images],
                "facebook_image_sha256": image_hashes,
                "facebook_content_hash": fingerprint,
                "facebook_error": None,
                "facebook_force_override": self.force_publish,
            },
        )
        if self.force_publish:
            self.repository.record_event(
                job_id, details={"manual_override": "force_facebook_publish"}
            )
        diagnostics = self._diagnostics_dir(job_id)
        try:
            page, uploaded = await self._prepare_composer(
                target, post_text, images, job_id, diagnostics
            )
            preview = (self._job_dir(job_id) / "facebook-composer-preview.png").resolve()
            await page.screenshot(path=str(preview), full_page=True)
            self._pages[job_id] = page
            self.repository.transition(
                job_id,
                WorkflowStatus.FACEBOOK_WAITING_FOR_MANUAL_REVIEW,
                details={"preview_screenshot_path": str(preview)},
                data_patch={
                    "facebook_preview_screenshot_path": str(preview),
                    "facebook_uploaded_preview_count": uploaded,
                },
            )
            return FacebookPostPreparationResult(
                True, job_id, target, post_text, [str(path) for path in images],
                uploaded, len(images), str(preview), [], None,
            )
        except FacebookManualActionRequired as exc:
            return FacebookPostPreparationResult(
                False, job_id, target, post_text, [str(path) for path in images],
                0, len(images), error=str(exc),
            )
        except Exception as exc:
            await self._fail_with_diagnostics(
                job_id, None, "composer-open-failure", str(exc),
                allowed={WorkflowStatus.FACEBOOK_PREPARING},
                target=WorkflowStatus.FACEBOOK_PUBLISH_FAILED,
            )
            return FacebookPostPreparationResult(
                False, job_id, target, post_text, [str(path) for path in images],
                0, len(images), error=str(exc),
            )

    async def publish_prepared_post(self, *, job_id: str) -> FacebookPublishResult:
        job = self._require_job(job_id)
        if job.status is not WorkflowStatus.FACEBOOK_WAITING_FOR_MANUAL_REVIEW:
            raise ValueError(
                "Facebook publishing requires FACEBOOK_WAITING_FOR_MANUAL_REVIEW; "
                f"got {job.status.value}"
            )
        target = str(job.data.get("facebook_target_url") or "")
        post_text = str(job.data.get("facebook_post_text") or "")
        images = [Path(path) for path in job.data.get("facebook_image_paths") or []]
        page = self._pages.get(job_id)
        if page is None or getattr(page, "is_closed", lambda: False)():
            page, _ = await self._prepare_composer(
                target, post_text, images, job_id, self._diagnostics_dir(job_id)
            )
        self._display_final_gate(job_id, job.data)
        choice = self.confirmation_provider("Select [1-6]: ").strip()
        if choice != "1":
            if choice == "2":
                self.repository.transition(
                    job_id, WorkflowStatus.APPROVED,
                    details={"facebook_manual_gate": "cancelled"},
                )
            elif choice == "3":
                edited = self.edit_provider().strip()
                cdha_view_url = str(job.data.get("cdha_view_url") or "")
                self.content.validate_post_text(
                    edited, source_url=self._source_url(job_id), cdha_view_url=cdha_view_url
                )
                path = self.content.write_text_atomic(
                    self._job_dir(job_id) / "facebook_post.txt", edited
                )
                self.repository.update_data(job_id, {
                    "facebook_operator_text": edited,
                    "facebook_post_text": edited,
                    "facebook_post_text_path": str(path),
                })
                self.repository.transition(
                    job_id, WorkflowStatus.APPROVED,
                    details={"facebook_manual_gate": "post_text_edited_reprepare_required"},
                )
            elif choice == "4":
                raw = self.screenshot_selection_provider(
                    "Comma-separated screenshot filenames in desired approved subset: "
                )
                selected = [item.strip() for item in raw.split(",") if item.strip()]
                selected_paths, warnings = self.content.select_screenshots(job_id, selected)
                self.repository.update_data(job_id, {
                    "facebook_selected_screenshot_names": selected,
                    "facebook_image_paths": [str(path) for path in selected_paths],
                    "facebook_image_sha256": [self.content.image_sha256(path) for path in selected_paths],
                    "facebook_screenshot_warnings": warnings,
                })
                self.repository.transition(
                    job_id, WorkflowStatus.APPROVED,
                    details={"facebook_manual_gate": "screenshot_selection_changed_reprepare_required"},
                )
            elif choice == "5":
                self.repository.record_event(
                    job_id, details={"facebook_manual_gate": "resume_later"}
                )
            elif choice == "6":
                preview = Path(str(job.data.get("facebook_preview_screenshot_path") or ""))
                if preview.is_file():
                    subprocess.Popen(
                        ["xdg-open", str(preview)], stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL, start_new_session=True,
                    )
                self.repository.record_event(
                    job_id, details={"facebook_manual_gate": "preview_opened"}
                )
            else:
                self.repository.record_event(
                    job_id, details={"facebook_manual_gate": f"invalid_selection_{choice}"}
                )
            return FacebookPublishResult(
                False, job_id, target, warnings=["Publication was not approved"],
                error="Operator did not select Publish now",
            )
        if self.force_publish:
            warning = self.confirmation_provider(
                "FORCE MODE may create a duplicate. Type FORCE PUBLISH to continue: "
            ).strip()
            if warning != "FORCE PUBLISH":
                return FacebookPublishResult(False, job_id, target, error="Force confirmation failed")
        started = datetime.now(UTC)
        before_ids = await self._visible_post_ids(page)
        self.repository.transition(
            job_id,
            WorkflowStatus.FACEBOOK_PUBLISHING,
            details={"publication_started_at": started.isoformat()},
            data_patch={
                "facebook_publication_started_at": started.isoformat(),
                "facebook_known_post_ids": sorted(before_ids),
            },
        )
        try:
            button = await self.resolver.find_first(
                page, "facebook.publish_button", timeout_ms=10_000,
                diagnostics_dir=self._diagnostics_dir(job_id),
                context=f"job_id={job_id} state=FACEBOOK_PUBLISHING action=publish_exact_button",
            )
            await button.click()
            
            # Handle two-step publish flow (Tiếp -> Đăng)
            try:
                second_button = await self.resolver.find_first(
                    page, "facebook.post_button", timeout_ms=3_000
                )
                await second_button.click()
            except Exception:
                pass
            result, signals = await self._verify_publication(
                page, job_id, post_text, images, started, before_ids
            )
            if not result.success:
                paths = await self._save_diagnostics(page, job_id, "publish-verification-failure")
                self.repository.transition(
                    job_id,
                    WorkflowStatus.FACEBOOK_PUBLISH_UNCERTAIN,
                    details={"verification_signals": signals},
                    data_patch={
                        "facebook_publication_uncertain": True,
                        "facebook_verification_signals": signals,
                        "facebook_diagnostic_screenshot_path": str(paths[0]),
                        "facebook_error": result.error,
                    },
                )
                return result
            completed = datetime.now(UTC)
            self.repository.transition(
                job_id,
                WorkflowStatus.FACEBOOK_PUBLISHED,
                details={"verification_signals": signals},
                data_patch={
                    "facebook_publication_verified": True,
                    "facebook_publication_completed_at": completed.isoformat(),
                    "facebook_verification_signals": signals,
                    "facebook_post_id": result.post_id,
                    "facebook_post_url_candidate": result.post_url,
                    "facebook_error": None,
                },
            )
            return result
        except Exception as exc:
            paths = await self._save_diagnostics(page, job_id, "publish-verification-failure")
            current = self._require_job(job_id)
            if current.status is WorkflowStatus.FACEBOOK_PUBLISHING:
                self.repository.transition(
                    job_id, WorkflowStatus.FACEBOOK_PUBLISH_FAILED,
                    details={"error": str(exc)},
                    data_patch={
                        "facebook_error": str(exc),
                        "facebook_diagnostic_screenshot_path": str(paths[0]),
                    },
                )
            return FacebookPublishResult(
                False, job_id, target,
                diagnostic_screenshot_path=str(paths[0]), error=str(exc),
            )

    async def extract_new_post_permalink(
        self, *, job_id: str, publication_started_at: datetime
    ) -> FacebookPermalinkResult:
        job = self._require_job(job_id)
        if job.status is WorkflowStatus.POST_URL_EXTRACTION_FAILED:
            job = self.repository.transition(
                job_id, WorkflowStatus.RETRY_PENDING,
                details={"retry_step": "facebook_permalink"},
            )
        if job.status not in {WorkflowStatus.FACEBOOK_PUBLISHED, WorkflowStatus.RETRY_PENDING}:
            raise ValueError(f"Permalink extraction cannot run from {job.status.value}")
        self.repository.transition(job_id, WorkflowStatus.POST_URL_EXTRACTING)
        page: Any = None
        try:
            page = await self.chrome.new_page()
            target = str(job.data.get("facebook_target_url") or "")
            await page.goto(target, wait_until="domcontentloaded", timeout=self.settings.page_timeout_seconds*1000)
            await self._ensure_authenticated(page, job_id, "permalink-extraction-failure")
            candidate = await self._find_exact_new_post(
                page,
                str(job.data.get("facebook_post_text") or ""),
                publication_started_at,
                int(job.data.get("facebook_uploaded_preview_count") or 0),
                set(job.data.get("facebook_known_post_ids") or []),
            )
            if not candidate:
                raise RuntimeError("Exact newly published Facebook post could not be identified")
            permalink = self.normalize_permalink(candidate["url"], base_url=target)
            post_id = self.extract_post_id(permalink)
            expected_id = str(job.data.get("facebook_post_id") or "")
            if expected_id and post_id and expected_id != post_id:
                raise RuntimeError("Permalink does not refer to the verified post ID")
            self.repository.transition(
                job_id, WorkflowStatus.POST_URL_EXTRACTED,
                details={"extraction_method": candidate.get("method")},
                data_patch={
                    "facebook_post_url": permalink,
                    "facebook_post_id": post_id or expected_id or None,
                    "facebook_permalink_extraction_method": candidate.get("method"),
                },
            )
            return FacebookPermalinkResult(
                True, job_id, permalink, post_id or expected_id or None,
                candidate.get("method"), [], None,
            )
        except Exception as exc:
            if page is not None:
                await self._save_diagnostics(page, job_id, "permalink-extraction-failure")
            current = self._require_job(job_id)
            if current.status is WorkflowStatus.POST_URL_EXTRACTING:
                self.repository.transition(
                    job_id, WorkflowStatus.POST_URL_EXTRACTION_FAILED,
                    details={"error": str(exc)}, data_patch={"facebook_permalink_error": str(exc)},
                )
            return FacebookPermalinkResult(False, job_id, error=str(exc))

    async def add_permalink_comment(
        self, *, post_url: str, comment_text: str, job_id: str, image_path: Path | None = None
    ) -> FacebookCommentResult:
        job = self._require_job(job_id)
        if job.status is WorkflowStatus.COMMENT_FAILED:
            job = self.repository.transition(
                job_id, WorkflowStatus.RETRY_PENDING,
                details={"retry_step": "facebook_comment"},
            )
        if job.status not in {WorkflowStatus.POST_URL_EXTRACTED, WorkflowStatus.RETRY_PENDING}:
            raise ValueError(f"Facebook commenting cannot run from {job.status.value}")
        normalized_url = self.normalize_permalink(post_url, base_url=post_url)
        self.repository.transition(job_id, WorkflowStatus.COMMENT_ADDING)
        page: Any = None
        try:
            existing_result = job.data.get("facebook_comment_result") or {}
            if existing_result.get("success") and self._same_comment(
                existing_result.get("comment_text", ""), comment_text
            ):
                return await self._complete_reused_comment(job_id, normalized_url, comment_text)
            page = await self.chrome.new_page()
            await page.goto(normalized_url, wait_until="domcontentloaded", timeout=self.settings.page_timeout_seconds*1000)
            await self._ensure_authenticated(page, job_id, "comment-failure")
            comments = await self._all_texts(page, "facebook.visible_comment")
            if any(self._same_comment(value, comment_text) for value in comments):
                return await self._complete_reused_comment(job_id, normalized_url, comment_text)
            # For Reels, the comment section might be hidden. Try clicking the comment button first.
            try:
                toggle = page.locator('div[aria-label*="bình luận" i][role="button"], div[aria-label*="comment" i][role="button"]').first
                if await toggle.is_visible(timeout=2000):
                    await toggle.click()
            except Exception:
                pass
            
            box = await self.resolver.find_first(
                page, "facebook.comment_input", timeout_ms=10_000,
                diagnostics_dir=self._diagnostics_dir(job_id),
                context=f"job_id={job_id} state=COMMENT_ADDING action=comment_exact_post",
            )
            await box.fill(comment_text)
            if await self._input_text(box) != comment_text:
                raise RuntimeError("Facebook comment insertion verification failed")
            
            if image_path and image_path.exists():
                file_input = page.locator('input[type="file"][accept*="image"]').first
                await file_input.set_input_files(str(image_path))
                await page.wait_for_timeout(5000) # Wait for image to be attached
            try:
                submit = await self.resolver.find_first(page, "facebook.comment_submit", timeout_ms=2_000)
                await submit.click()
            except SelectorResolutionError:
                await box.focus()
                await box.press("Enter")
            await self._wait_for_visible_comment(page, comment_text)
            posted_at = datetime.now(UTC)
            result = FacebookCommentResult(
                True, job_id, normalized_url, None, comment_text, posted_at, [], None, False
            )
            self.repository.transition(
                job_id, WorkflowStatus.COMMENT_ADDED,
                details={"comment_reused": False},
                data_patch={"facebook_comment_result": result.to_dict()},
            )
            self.repository.transition(job_id, WorkflowStatus.COMPLETED)
            return result
        except Exception as exc:
            if page is not None:
                await self._save_diagnostics(page, job_id, "comment-failure")
            current = self._require_job(job_id)
            if current.status is WorkflowStatus.COMMENT_ADDING:
                self.repository.transition(
                    job_id, WorkflowStatus.COMMENT_FAILED,
                    details={"error": str(exc)}, data_patch={"facebook_comment_error": str(exc)},
                )
            return FacebookCommentResult(False, job_id, normalized_url, comment_text=comment_text, error=str(exc))

    async def is_authenticated(self, page: Any) -> bool:
        url = str(getattr(page, "url", "")).casefold()
        if any(value in url for value in ("/login", "/checkpoint", "two_factor")):
            return False
        if await self.resolver.exists(page, "facebook.login_indicators", timeout_ms=700):
            return False
        if await self.resolver.exists(page, "facebook.checkpoint_indicators", timeout_ms=700):
            return False
        return await self.resolver.exists(page, "facebook.authenticated_marker", timeout_ms=1_500)

    async def _prepare_composer(
        self, target: str, post_text: str, images: list[Path], job_id: str, diagnostics: Path
    ) -> tuple[Any, int]:
        page = await self.chrome.new_page()
        self._pages[job_id] = page
        await page.goto(target, wait_until="domcontentloaded", timeout=self.settings.page_timeout_seconds*1000)
        await self._ensure_authenticated(page, job_id, "composer-open-failure")
        if await self.resolver.exists(page, "facebook.target_access_denied", timeout_ms=1_200):
            raise RuntimeError("Facebook target is unavailable or posting permission is missing")
        entry = await self.resolver.find_first(
            page, "facebook.create_post_entry", timeout_ms=10_000,
            diagnostics_dir=diagnostics,
            context=f"job_id={job_id} state=FACEBOOK_PREPARING action=open_composer",
        )
        await entry.click()
        await self.resolver.find_first(
            page, "facebook.composer_dialog", timeout_ms=10_000,
            diagnostics_dir=diagnostics,
            context=f"job_id={job_id} state=FACEBOOK_PREPARING action=verify_dialog",
        )
        textbox = await self.resolver.find_first(
            page, "facebook.composer_textbox", timeout_ms=10_000,
            diagnostics_dir=diagnostics,
            context=f"job_id={job_id} state=FACEBOOK_PREPARING action=insert_text",
        )
        await textbox.fill(post_text)
        if await self._input_text(textbox) != post_text:
            raise RuntimeError("Facebook composer text read-back did not match approved content")
        file_input = await self.resolver.find_first(
            page, "facebook.file_input", visible=False, timeout_ms=10_000,
            diagnostics_dir=diagnostics,
            context=f"job_id={job_id} state=FACEBOOK_PREPARING action=upload_images",
        )
        try:
            await file_input.set_input_files([str(path) for path in images])
            uploaded = await self._wait_for_uploads(page, len(images))
        except Exception:
            await self._save_diagnostics(page, job_id, "image-upload-failure")
            raise
        # Just ensure the publish button is present in the DOM
        button = await self.resolver.find_first(
            page, "facebook.publish_button", timeout_ms=10_000,
            diagnostics_dir=diagnostics,
            context=f"job_id={job_id} state=FACEBOOK_PREPARING action=verify_publish_ready",
        )
        return page, uploaded

    async def _ensure_authenticated(self, page: Any, job_id: str, diagnostic_name: str) -> None:
        if await self.is_authenticated(page):
            return
        await self._save_diagnostics(page, job_id, diagnostic_name)
        try:
            await self.chrome.wait_for_manual_action(
                "Complete Facebook login, 2FA, CAPTCHA, checkpoint, or account verification manually. No challenge will be bypassed.",
                lambda: self.is_authenticated(page),
            )
        except Exception as exc:
            raise FacebookManualActionRequired(
                "Facebook authentication was not verified; job remains resumable"
            ) from exc
        if not await self.is_authenticated(page):
            raise FacebookManualActionRequired("Facebook authentication was not verified; job remains resumable")

    async def _wait_for_uploads(self, page: Any, expected: int) -> int:
        deadline = time.monotonic() + self.settings.facebook_upload_timeout_seconds
        while time.monotonic() < deadline:
            if await self.resolver.exists(page, "facebook.upload_error", timeout_ms=400):
                raise RuntimeError("Facebook reported an image upload error")
            progress = await self.resolver.exists(page, "facebook.upload_progress", timeout_ms=300)
            count = await self._count_all(page, "facebook.uploaded_preview")
            if not progress and count >= expected:
                return count
            await asyncio.sleep(0.5)
        raise TimeoutError(
            f"Facebook upload previews did not reach expected count {expected} before timeout"
        )

    async def _verify_publication(
        self, page: Any, job_id: str, text: str, images: list[Path],
        started: datetime, before_ids: set[str]
    ) -> tuple[FacebookPublishResult, dict[str, Any]]:
        deadline = time.monotonic() + self.settings.facebook_publish_timeout_seconds
        signals: dict[str, Any] = {}
        candidate: dict[str, Any] | None = None
        while time.monotonic() < deadline:
            signals["success_notification"] = await self.resolver.exists(
                page, "facebook.publish_success", timeout_ms=400
            )
            signals["composer_closed"] = not await self.resolver.exists(
                page, "facebook.composer_dialog", timeout_ms=300
            )
            candidate = await self._find_exact_new_post(
                page, text, started, len(images), before_ids
            )
            signals["exact_post_match"] = bool(candidate)
            signals["text_match"] = bool(candidate and candidate.get("text_match"))
            signals["recent_timestamp"] = bool(candidate and candidate.get("recent"))
            signals["image_count_match"] = bool(
                candidate and candidate.get("image_count") == len(images)
            )
            if self.publication_is_verified(signals):
                url = candidate.get("url") if candidate else None
                post_id = self.extract_post_id(url or "")
                methods = [key for key, value in signals.items() if value]
                return FacebookPublishResult(
                    True, job_id, self._require_job(job_id).data.get("facebook_target_url", ""),
                    post_id, url, datetime.now(UTC), "+".join(methods), None, [], None,
                ), signals
            await asyncio.sleep(1)
        return FacebookPublishResult(
            False, job_id, self._require_job(job_id).data.get("facebook_target_url", ""),
            warnings=["Publication could not be verified strongly enough"],
            error="Facebook publication outcome is uncertain",
        ), signals

    @staticmethod
    def publication_is_verified(signals: dict[str, Any]) -> bool:
        strong = bool(signals.get("success_notification") or signals.get("exact_post_match"))
        supporting = sum(
            bool(signals.get(key))
            for key in ("composer_closed", "text_match", "recent_timestamp", "image_count_match")
        )
        return strong and supporting >= 1

    async def _find_exact_new_post(
        self, page: Any, approved_text: str, started: datetime,
        expected_images: int, before_ids: set[str]
    ) -> dict[str, Any] | None:
        articles = await self._all_locators(page, "facebook.feed_post")
        normalized_approved = self._normalize_text(approved_text)
        best: tuple[int, dict[str, Any]] | None = None
        for article in articles:
            try:
                body = self._normalize_text(await article.inner_text())
                text_match = normalized_approved == body or normalized_approved in body
                links = await self._article_links(article)
                for href in links:
                    try:
                        url = self.normalize_permalink(href, base_url=str(page.url))
                    except ValueError:
                        continue
                    post_id = self.extract_post_id(url) or ""
                    is_new = not post_id or post_id not in before_ids
                    images = await article.locator("img[src]").count()
                    recent = await self._article_is_recent(article, started)
                    score = 4 * text_match + 2 * is_new + int(recent) + int(images == expected_images)
                    candidate = {
                        "url": url, "post_id": post_id, "text_match": text_match,
                        "recent": recent, "image_count": images,
                        "method": "content+new-id+timestamp+image-count",
                    }
                    if text_match and is_new and (best is None or score > best[0]):
                        best = (score, candidate)
            except Exception:
                continue
        return best[1] if best else None

    async def _article_links(self, article: Any) -> list[str]:
        links: list[str] = []
        for candidate in self.resolver.candidates("facebook.post_timestamp_link"):
            try:
                locator = self.resolver._locator(article, candidate)
                for index in range(await locator.count()):
                    href = await locator.nth(index).get_attribute("href")
                    if href:
                        links.append(href)
            except Exception:
                continue
        return links

    async def _article_is_recent(self, article: Any, started: datetime) -> bool:
        try:
            raw = await article.locator("time").first.get_attribute("datetime")
            if raw:
                value = datetime.fromisoformat(raw.replace("Z", "+00:00"))
                return value >= started - timedelta(minutes=5)
        except Exception:
            pass
        return False

    @classmethod
    def normalize_permalink(cls, href: str, *, base_url: str) -> str:
        absolute = urljoin(base_url, str(href or "").strip())
        parsed = urlsplit(absolute)
        host = (parsed.hostname or "").lower()
        if host not in {"facebook.com", "www.facebook.com", "m.facebook.com"}:
            raise ValueError("Permalink is not a Facebook URL")
        path = re.sub(r"/{2,}", "/", parsed.path).rstrip("/")
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        allowed_query: dict[str, str] = {}
        if path.endswith("/story.php") or path == "/story.php":
            if query.get("story_fbid"):
                allowed_query["story_fbid"] = query["story_fbid"]
            if query.get("id"):
                allowed_query["id"] = query["id"]
        elif path.endswith("/photo.php") or path == "/photo.php":
            if query.get("fbid"):
                allowed_query["fbid"] = query["fbid"]
        valid_path = bool(re.search(
            r"/(?:posts|permalink|reel|share/(?:v|p))/[^/]+$|/groups/[^/]+/posts/[^/]+$", path
        ))
        valid_query = bool(allowed_query)
        if not (valid_path or valid_query):
            raise ValueError("Facebook URL is not a supported post permalink")
        return urlunsplit(("https", "www.facebook.com", path, urlencode(allowed_query), ""))

    @staticmethod
    def extract_post_id(url: str) -> str | None:
        parsed = urlsplit(url)
        query = dict(parse_qsl(parsed.query))
        for key in ("story_fbid", "fbid"):
            if query.get(key):
                return query[key]
        match = re.search(r"/(?:posts|permalink|reel)/([^/?]+)$", parsed.path.rstrip("/"))
        return match.group(1) if match else None

    async def _visible_post_ids(self, page: Any) -> set[str]:
        ids: set[str] = set()
        for article in await self._all_locators(page, "facebook.feed_post"):
            for href in await self._article_links(article):
                try:
                    post_id = self.extract_post_id(self.normalize_permalink(href, base_url=str(page.url)))
                    if post_id:
                        ids.add(post_id)
                except ValueError:
                    continue
        return ids

    def _guard_duplicate(self, job_id: str, target: str, fingerprint: str) -> None:
        duplicates = self.repository.find_facebook_duplicates(
            fingerprint, target, exclude_job_id=job_id
        )
        for duplicate in duplicates:
            verified = bool(
                duplicate.data.get("facebook_publication_verified")
                or duplicate.data.get("facebook_post_url")
            )
            uncertain = bool(
                duplicate.status is WorkflowStatus.FACEBOOK_PUBLISH_UNCERTAIN
                or duplicate.data.get("facebook_publication_uncertain")
            )
            if (verified or uncertain) and not self.force_publish:
                kind = "uncertain prior publication" if uncertain else "verified existing post"
                raise ValueError(f"Duplicate Facebook publication blocked: {kind} in job {duplicate.job_id}")

    async def _complete_reused_comment(
        self, job_id: str, post_url: str, comment_text: str
    ) -> FacebookCommentResult:
        result = FacebookCommentResult(
            True, job_id, post_url, None, comment_text, datetime.now(UTC),
            ["Matching permalink comment already exists"], None, True,
        )
        self.repository.transition(
            job_id, WorkflowStatus.COMMENT_ADDED,
            details={"comment_reused": True},
            data_patch={"facebook_comment_result": result.to_dict()},
        )
        self.repository.transition(job_id, WorkflowStatus.COMPLETED)
        return result

    async def _wait_for_visible_comment(self, page: Any, text: str) -> None:
        deadline = time.monotonic() + self.settings.facebook_publish_timeout_seconds
        while time.monotonic() < deadline:
            if any(self._same_comment(value, text) for value in await self._all_texts(page, "facebook.visible_comment")):
                return
            if await self.resolver.exists(page, "facebook.error_banner", timeout_ms=300):
                raise RuntimeError("Facebook displayed an error while posting the comment")
            await asyncio.sleep(0.5)
        raise TimeoutError("Facebook comment did not appear before timeout")

    async def _count_all(self, page: Any, key: str) -> int:
        total = 0
        for candidate in self.resolver.candidates(key):
            try:
                total = max(total, await self.resolver._locator(page, candidate).count())
            except Exception:
                continue
        return total

    async def _all_locators(self, page: Any, key: str) -> list[Any]:
        values: list[Any] = []
        for candidate in self.resolver.candidates(key):
            try:
                locator = self.resolver._locator(page, candidate)
                count = await locator.count()
                if count:
                    return [locator.nth(i) for i in range(count)]
            except Exception:
                continue
        return values

    async def _all_texts(self, page: Any, key: str) -> list[str]:
        values: list[str] = []
        for locator in await self._all_locators(page, key):
            try:
                values.append((await locator.inner_text()).strip())
            except Exception:
                continue
        return values

    async def _save_diagnostics(self, page: Any, job_id: str, name: str) -> tuple[Path, Path]:
        folder = self._diagnostics_dir(job_id)
        folder.mkdir(parents=True, exist_ok=True)
        screenshot = (folder / f"{name}.png").resolve()
        html = (folder / f"{name}.html").resolve()
        await page.screenshot(path=str(screenshot), full_page=True)
        html.write_text(await page.content(), encoding="utf-8")
        return screenshot, html

    async def _fail_with_diagnostics(
        self, job_id: str, page: Any | None, name: str, error: str,
        *, allowed: set[WorkflowStatus], target: WorkflowStatus
    ) -> None:
        paths: tuple[Path, Path] | None = None
        actual_page = page or self._pages.get(job_id)
        if actual_page is not None:
            paths = await self._save_diagnostics(actual_page, job_id, name)
        current = self._require_job(job_id)
        if current.status in allowed:
            patch: dict[str, Any] = {"facebook_error": error}
            if paths:
                patch["facebook_failure_screenshot_path"] = str(paths[0])
                patch["facebook_failure_html_path"] = str(paths[1])
            self.repository.transition(
                job_id, target, details={"error": error}, data_patch=patch
            )

    def _display_final_gate(self, job_id: str, data: dict[str, Any]) -> None:
        print("=" * 50)
        print("FACEBOOK POST READY")
        print("=" * 50)
        print(f"Job ID: {job_id}")
        print(f"Target: {data.get('facebook_target_url') or ''}")
        print(f"Post text path: {data.get('facebook_post_text_path') or ''}")
        print(f"Expected images: {len(data.get('facebook_image_paths') or [])}")
        print(f"Uploaded previews: {data.get('facebook_uploaded_preview_count') or 0}")
        print(f"Preview screenshot: {data.get('facebook_preview_screenshot_path') or ''}")
        print(f"Source Reel: {data.get('source_url') or self._source_url(job_id)}")
        print(f"CDHA result: {data.get('cdha_result_json_path') or ''}")
        print("[1] Publish now\n[2] Cancel and keep APPROVED\n[3] Edit post text")
        print("[4] Change screenshot selection\n[5] Save and resume later\n[6] Open preview screenshot")

    @staticmethod
    def _read_multiline_edit() -> str:
        print("Paste the complete Facebook post text. Enter a single '.' line to finish:")
        lines: list[str] = []
        while True:
            line = input()
            if line == ".":
                return "\n".join(lines)
            lines.append(line)

    def _source_url(self, job_id: str) -> str:
        job = self._require_job(job_id)
        return job.source_url

    def _require_job(self, job_id: str) -> Any:
        job = self.repository.get_job(job_id)
        if job is None:
            raise LookupError(f"Job not found: {job_id}")
        return job

    def _job_dir(self, job_id: str) -> Path:
        return (self.settings.job_data_dir / job_id).resolve()

    def _diagnostics_dir(self, job_id: str) -> Path:
        return self._job_dir(job_id) / "browser_snapshots" / "facebook"

    @staticmethod
    async def _input_text(locator: Any) -> str:
        try:
            return await locator.input_value()
        except Exception:
            return (await locator.text_content() or "").strip()

    @staticmethod
    def _normalize_text(value: str) -> str:
        return " ".join(str(value or "").split()).casefold()

    @classmethod
    def _same_comment(cls, left: str, right: str) -> bool:
        norm_left = cls._normalize_text(left)
        norm_right = cls._normalize_text(right)
        if norm_left == norm_right:
            return True
        if norm_right.startswith("chi tiết:") and norm_left.startswith("chi tiết:"):
            return True
        if norm_right.startswith("copy link chia sẻ:") and norm_left.startswith("copy link chia sẻ:"):
            return True
        return False
